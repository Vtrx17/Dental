# 🦷 FYP Tooth Measurement System

## 📖 **What is This Code About?**

This is an **AI-powered dental tooth measurement system** that uses deep learning to:
1. **Detect** individual teeth in dental images
2. **Segment** each tooth with pixel-level accuracy
3. **Classify** teeth into 17 different types (incisors, canines, premolars, molars)
4. **Measure** tooth dimensions (area, width, height, perimeter)
5. **Export** measurements to CSV for analysis

The system is designed for dental imaging analysis, orthodontic planning, and research applications.

---

## 🧠 **Model Architecture: U-Net**

### What is U-Net?
U-Net is a **Convolutional Neural Network (CNN)** designed for image segmentation. It has an **encoder-decoder** structure:

```
Input Image (256x256x3)
       ↓
┌─────────────────────────────────┐
│        ENCODER (Downsampling)   │
│  enc1 → enc2 → enc3 → enc4      │
│  64    128    256    512        │
│         (feature extraction)    │
└─────────────────────────────────┘
       ↓
┌─────────────────────────────────┐
│          BOTTLENECK             │
│            1024 channels        │
└─────────────────────────────────┘
       ↓
┌─────────────────────────────────┐
│        DECODER (Upsampling)     │
│  dec4 → dec3 → dec2 → dec1      │
│  512    256    128    64        │
│    (spatial reconstruction)     │
└─────────────────────────────────┘
       ↓
Output Mask (256x256x17)
```

### Why U-Net for Teeth?
- ✅ **Skip connections** preserve fine details (tooth edges)
- ✅ Works well with limited training data (249 images)
- ✅ Pixel-level segmentation for accurate measurements
- ✅ Handles multiple classes (17 tooth types)

### Model Specifications:
| Parameter | Value |
|-----------|-------|
| Architecture | U-Net with BatchNorm |
| Input Size | 256 × 256 × 3 (RGB) |
| Output Classes | 17 (background + 16 teeth) |
| Encoder Channels | 64 → 128 → 256 → 512 |
| Bottleneck | 1024 channels |
| Total Parameters | ~31 million |

---

## 🎭 **What is the Mask?**

### Definition
A **segmentation mask** is a 2D array where each pixel contains a **class ID** indicating what that pixel belongs to.

### Example:
```
Original Image:        Predicted Mask:
┌─────────────┐        ┌─────────────┐
│  🦷  🦷  🦷  │   →    │  1  2  3    │  (class IDs)
│  gum  gum   │        │  0  0  0    │  (0 = background)
└─────────────┘        └─────────────┘
```

### Class Mapping:
| Class ID | Name | Tooth Type |
|----------|------|------------|
| 0 | teeth | Central incisor |
| 1 | teeth_2 | Lateral incisor |
| 2 | teeth_3 | Canine |
| 3-4 | teeth_4-5 | Premolars |
| 5-10 | teeth_6-11 | Molars (various) |
| 11-16 | teeth_12-17 | Additional teeth |

### Mask Uses:
1. **Visualization** - Color each tooth differently
2. **Measurement** - Count pixels for area calculation
3. **Instance Separation** - Identify individual teeth
4. **Confidence Mapping** - Show prediction certainty

---

## ⚙️ **System Workflow**

```
┌─────────────────────────────────────────────────────────────────────┐
│                        SYSTEM PIPELINE                               │
└─────────────────────────────────────────────────────────────────────┘

    ┌──────────┐      ┌──────────┐      ┌──────────┐      ┌──────────┐
    │  INPUT   │  →   │  MODEL   │  →   │   POST   │  →   │  OUTPUT  │
    │  IMAGE   │      │ INFERENCE│      │ PROCESS  │      │ RESULTS  │
    └──────────┘      └──────────┘      └──────────┘      └──────────┘
         │                 │                 │                 │
    Load dental      U-Net predicts    Watershed         Measurements
    image            mask + conf       separates         saved to CSV
                                       teeth
```

### Step-by-Step:

1. **Load Image** → Read dental photo (any resolution)
2. **Preprocess** → Resize to 256×256, normalize
3. **Inference** → U-Net outputs 17-channel probability map
4. **Argmax** → Convert probabilities to class IDs (mask)
5. **Post-process** → Morphological cleanup, watershed separation
6. **Measure** → Calculate area, perimeter, dimensions
7. **Export** → Save to CSV + visualization images

---

## 📁 **Project Structure**

```
CODEv3/
├── 📂 models/                    # Model architectures
│   ├── unet_model.py             # Original U-Net (16-class)
│   └── unet_colab.py             # Colab-trained U-Net (17-class)
│
├── 📂 data/                      # Dataset
│   └── Segmentation-Dental-1/    # Roboflow COCO annotations
│
├── 📂 results/                   # Output
│   └── measurements/             # Saved tooth images
│
├── 📂 bin/                       # Helper scripts (20 files)
│
├── 🔵 Core Files:
│   ├── interactive_measure_16class.py  ⭐ MAIN GUI
│   ├── colab_interactive_measure.py    Colab version
│   ├── confusion_matrix_cell.py        Accuracy viz
│   ├── train_teeth_segmentation_250epochs.ipynb  Training
│   ├── auto_measure.py                 Batch processing
│   └── ml_postprocessing.py            TTA/CRF
│
└── 📊 measurements.csv           # Exported data
```

---

## 🔵 **Core Files Explained**

### 1. `interactive_measure_16class.py` ⭐
**Main interactive GUI for tooth measurement**

```python
# Key Functions:
load_model()                    # Load U-Net weights
run_inference_with_confidence() # Get mask + confidence
segment_individual_teeth()      # Watershed separation
calculate_measurements()        # Area, width, height
save_to_csv()                   # Export results
```

**Usage:**
```bash
python interactive_measure_16class.py
# Click on any tooth to measure it!
```

---

### 2. `train_teeth_segmentation_250epochs.ipynb`
**Google Colab training notebook**

**Features:**
- Downloads Roboflow dataset automatically
- 250 epochs with cosine annealing
- Data augmentation (flip, rotate, color jitter)
- Saves best model based on validation loss

---

### 3. `confusion_matrix_cell.py`
**Visualizes per-class accuracy**

Shows which teeth types are well-detected vs. confused:
- Front teeth: 97% accuracy
- Middle teeth: 20-45% (visually similar)
- Molars: 72-80% accuracy

---

## 📊 **Models**

| Model File | Classes | Training | Architecture |
|------------|---------|----------|--------------|
| `best_unet_16class.pt` | 16 | 80 epochs | unet_model.py |
| `best_unet_250epochs.pt` | 17 | 250 epochs | unet_colab.py |

**⚠️ Important:** Use matching architecture file when loading model!

---

## 🚀 **Quick Start**

### Local (Windows):
```bash
# 1. Activate conda
conda activate base

# 2. Run interactive measurement
python interactive_measure_16class.py

# 3. Click on teeth to measure!
```

### Google Colab:
1. Upload `train_teeth_segmentation_250epochs.ipynb`
2. Run all cells (trains ~8 hours on T4 GPU)
3. Add `confusion_matrix_cell.py` for accuracy
4. Add `colab_interactive_measure.py` to measure

---

## � **Performance**

| Metric | Value |
|--------|-------|
| Overall Accuracy | 92-96% |
| Front Teeth (distinctive) | 97% |
| Middle Teeth (similar) | 20-45% |
| Back Molars (large) | 72-80% |
| Inference Time | ~0.1s per image |
| Training Time | 8-10 hours (250 epochs) |

---

## 📋 **Output: measurements.csv**

| Column | Description |
|--------|-------------|
| timestamp | When measured |
| image_filename | Source image |
| tooth_class | Tooth ID (Tooth_1, etc.) |
| surface_area_mm2 | Area in mm² |
| width_mm | Width in mm |
| height_mm | Height in mm |
| perimeter_mm | Perimeter in mm |
| centroid_x/y/z | Center position |
| confidence | Model confidence (0-1) |
| num_pixels | Pixel count |

---

## 🎓 **For FYP Presentation**

**Key Technical Points:**
1. ✅ U-Net CNN for semantic segmentation
2. ✅ 17-class tooth classification
3. ✅ 250-epoch training with augmentation
4. ✅ Watershed for instance separation
5. ✅ Interactive GUI with real-time measurement

**Known Limitations:**
- Middle teeth (premolars) have lower accuracy due to visual similarity
- Works best on real dental photos, not synthetic renders
- Requires calibration for accurate mm measurements

---

## 📂 **Bin Folder**

Contains 20 helper scripts used during development:
- Dataset analyzers
- Notebook generators
- Bug fix scripts
- Testing utilities

**Not required for main system operation.**

---

## 📊 **System Flowcharts**

### 1. Overall System Flow

```mermaid
flowchart TD
    A[📷 Input Dental Image] --> B[🔄 Preprocessing]
    B --> C{Load U-Net Model}
    C --> D[🧠 Run Inference]
    D --> E[📊 Get Probability Map]
    E --> F[🎭 Generate Mask via Argmax]
    F --> G[🧹 Post-Processing]
    G --> H[💧 Watershed Separation]
    H --> I[📏 Calculate Measurements]
    I --> J[💾 Save to CSV]
    I --> K[🖼️ Visualization]
    
    style A fill:#e1f5fe
    style D fill:#fff3e0
    style F fill:#e8f5e9
    style I fill:#fce4ec
    style J fill:#f3e5f5
```

---

### 2. U-Net Model Architecture

```mermaid
flowchart TB
    subgraph ENCODER ["📥 ENCODER (Downsampling)"]
        E1["enc1: 3→64 ch"] --> P1["MaxPool 2x2"]
        P1 --> E2["enc2: 64→128 ch"]
        E2 --> P2["MaxPool 2x2"]
        P2 --> E3["enc3: 128→256 ch"]
        E3 --> P3["MaxPool 2x2"]
        P3 --> E4["enc4: 256→512 ch"]
        E4 --> P4["MaxPool 2x2"]
    end
    
    subgraph BOTTLENECK ["🔵 BOTTLENECK"]
        B["512→1024 ch"]
    end
    
    subgraph DECODER ["📤 DECODER (Upsampling)"]
        D4["dec4: 1024→512 ch"] --> U3["UpConv 2x2"]
        U3 --> D3["dec3: 512→256 ch"]
        D3 --> U2["UpConv 2x2"]
        U2 --> D2["dec2: 256→128 ch"]
        D2 --> U1["UpConv 2x2"]
        U1 --> D1["dec1: 128→64 ch"]
    end
    
    P4 --> B
    B --> D4
    
    E4 -.->|Skip Connection| D4
    E3 -.->|Skip Connection| D3
    E2 -.->|Skip Connection| D2
    E1 -.->|Skip Connection| D1
    
    D1 --> OUT["outconv: 64→17 classes"]
    
    style ENCODER fill:#e3f2fd
    style BOTTLENECK fill:#fff9c4
    style DECODER fill:#e8f5e9
```

---

### 3. Training Pipeline

```mermaid
flowchart LR
    subgraph DATASET ["📂 Dataset Preparation"]
        A1[Roboflow Dataset] --> A2[COCO Annotations]
        A2 --> A3[249 Train + 63 Val Images]
    end
    
    subgraph AUGMENTATION ["🔄 Data Augmentation"]
        B1[Horizontal Flip]
        B2[Vertical Flip]
        B3[Rotation ±15°]
        B4[Color Jitter]
    end
    
    subgraph TRAINING ["🏋️ Training Loop"]
        C1[Forward Pass] --> C2[Compute Loss]
        C2 --> C3[Backpropagation]
        C3 --> C4[Update Weights]
        C4 --> C5{Best Val Loss?}
        C5 -->|Yes| C6[Save Model]
        C5 -->|No| C1
    end
    
    A3 --> AUGMENTATION
    AUGMENTATION --> TRAINING
    
    style DATASET fill:#e1f5fe
    style AUGMENTATION fill:#fff3e0
    style TRAINING fill:#e8f5e9
```

---

### 4. Inference & Measurement Pipeline

```mermaid
flowchart TD
    subgraph INPUT ["📷 Input Processing"]
        I1[Load Image] --> I2[Resize to 256x256]
        I2 --> I3[Normalize RGB]
        I3 --> I4[Convert to Tensor]
    end
    
    subgraph INFERENCE ["🧠 Model Inference"]
        M1[U-Net Forward Pass] --> M2[17-channel Output]
        M2 --> M3[Softmax Probabilities]
        M3 --> M4[Argmax → Class IDs]
        M3 --> M5[Max → Confidence Map]
    end
    
    subgraph POSTPROCESS ["🧹 Post-Processing"]
        P1[Morphological Open] --> P2[Morphological Close]
        P2 --> P3[Distance Transform]
        P3 --> P4[Peak Detection]
        P4 --> P5[Watershed Separation]
    end
    
    subgraph MEASURE ["📏 Measurement"]
        Q1[Count Pixels → Area]
        Q2[Bounding Box → Width/Height]
        Q3[Contour → Perimeter]
        Q4[Mean Position → Centroid]
    end
    
    subgraph OUTPUT ["💾 Output"]
        O1[measurements.csv]
        O2[Visualization Image]
        O3[Interactive GUI]
    end
    
    INPUT --> INFERENCE
    INFERENCE --> POSTPROCESS
    POSTPROCESS --> MEASURE
    MEASURE --> OUTPUT
    
    style INPUT fill:#e1f5fe
    style INFERENCE fill:#fff9c4
    style POSTPROCESS fill:#e8f5e9
    style MEASURE fill:#fce4ec
    style OUTPUT fill:#f3e5f5
```

---

### 5. Interactive Measurement Flow

```mermaid
flowchart TD
    START([🚀 Start Program]) --> LOAD[Load Model & Image]
    LOAD --> INFER[Run Inference]
    INFER --> SEG[Segment Individual Teeth]
    SEG --> VIS[Display Colored Overlay]
    VIS --> WAIT{User Clicks?}
    
    WAIT -->|Click on Tooth| GET[Get Clicked Instance]
    GET --> CALC[Calculate Measurements]
    CALC --> SHOW[Display Results]
    SHOW --> CSV[Save to CSV]
    CSV --> IMG[Save Tooth Image]
    IMG --> UPDATE[Update Visualization]
    UPDATE --> WAIT
    
    WAIT -->|Close Window| END([✅ Session Complete])
    
    style START fill:#c8e6c9
    style END fill:#c8e6c9
    style CALC fill:#fff3e0
    style CSV fill:#e1f5fe
```

---

### 6. File Dependencies

```mermaid
flowchart TB
    subgraph CORE ["🔵 Core System"]
        MAIN["interactive_measure_16class.py"]
        COLAB["colab_interactive_measure.py"]
    end
    
    subgraph MODELS ["📦 Models"]
        UNET["models/unet_colab.py"]
        WEIGHTS["best_unet_250epochs.pt"]
    end
    
    subgraph DATA ["📂 Data"]
        DATASET["Segmentation-Dental-1/"]
        INPUT["Input Images"]
    end
    
    subgraph OUTPUT ["💾 Output"]
        CSV["measurements.csv"]
        RESULTS["results/measurements/"]
    end
    
    MAIN --> UNET
    MAIN --> WEIGHTS
    MAIN --> INPUT
    MAIN --> CSV
    MAIN --> RESULTS
    
    COLAB --> WEIGHTS
    COLAB --> INPUT
    
    style CORE fill:#e3f2fd
    style MODELS fill:#fff9c4
    style DATA fill:#e8f5e9
    style OUTPUT fill:#fce4ec
```

---

## 📌 **Quick Reference Card**

```
┌────────────────────────────────────────────────────────────────────┐
│                    FYP TOOTH MEASUREMENT SYSTEM                     │
├────────────────────────────────────────────────────────────────────┤
│  MODEL:     U-Net (17 classes, 31M parameters)                     │
│  INPUT:     Any dental photo → resized to 256×256                  │
│  OUTPUT:    Segmentation mask + measurements in CSV                │
│  ACCURACY:  92-96% overall, 97% on front teeth                     │
├────────────────────────────────────────────────────────────────────┤
│  RUN:       python interactive_measure_16class.py                  │
│  TRAIN:     Upload train_teeth_segmentation_250epochs.ipynb        │
├────────────────────────────────────────────────────────────────────┤
│  KEY FILES:                                                         │
│  • interactive_measure_16class.py  ← Main GUI                      │
│  • models/unet_colab.py            ← Model architecture            │
│  • measurements.csv                ← Output data                   │
└────────────────────────────────────────────────────────────────────┘
```
