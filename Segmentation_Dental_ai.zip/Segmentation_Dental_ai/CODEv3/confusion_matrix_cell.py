# ========== PASTE THIS AS A NEW CELL IN COLAB ==========
# Normalized Confusion Matrix - Matching your design

from sklearn.metrics import confusion_matrix
import seaborn as sns
import numpy as np

print("Generating normalized confusion matrix...")

# Collect all predictions and ground truth
model.eval()
all_preds = []
all_labels = []

with torch.no_grad():
    for imgs, masks in tqdm(val_loader, desc='Computing confusion matrix'):
        imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)
        outputs = model(imgs)
        preds = outputs.argmax(1)
        
        all_preds.append(preds.cpu().flatten())
        all_labels.append(masks.cpu().flatten())

all_preds = torch.cat(all_preds).numpy()
all_labels = torch.cat(all_labels).numpy()

# Compute confusion matrix
cm = confusion_matrix(all_labels, all_preds, labels=list(range(NUM_CLASSES)))

# Normalize by row (per class)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

# Create class labels (teeth, teeth_2, teeth_3, ..., teeth_16)
class_labels = ['teeth'] + [f'teeth_{i}' for i in range(2, NUM_CLASSES + 1)]
class_labels = class_labels[:NUM_CLASSES]  # Trim to actual number of classes

# Plot with custom styling
plt.figure(figsize=(14, 12))
sns.heatmap(cm_normalized, annot=True, fmt='.2f', 
            cmap='RdYlBu_r',  # Red-Yellow-Blue reversed (matches your design)
            xticklabels=class_labels,
            yticklabels=class_labels,
            cbar_kws={'label': 'Normalized count'},
            vmin=0, vmax=1)

plt.title('Confusion Matrix - Per Class Normalized', fontsize=16, fontweight='bold')
plt.xlabel('Predicted Class', fontsize=12)
plt.ylabel('True Class', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.tight_layout()
plt.show()

# Print per-class accuracy
print("\nPer-Class Accuracy (Diagonal values):")
for i in range(NUM_CLASSES):
    if cm[i].sum() > 0:
        acc = cm_normalized[i, i] * 100
        print(f"  {class_labels[i]}: {acc:.2f}%")
