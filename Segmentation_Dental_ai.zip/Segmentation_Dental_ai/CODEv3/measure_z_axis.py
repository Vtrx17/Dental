import open3d as o3d
import numpy as np
import cv2
from PIL import Image

# ================= CONFIG =================
# To measure Z (Depth), we NEED a 3D file (.ply, .stl, .obj)
# Since we only have 2D images now, this is a TEMPLATE for when you export 3D data.
MESH_PATH = "data/sample_scan.ply"  # You need to provide this
MASK_2D_PATH = "results/2.Undercut_mask_unet.png"
# ==========================================

def measure_z_axis():
    print("=== 3D DEPTH (Z-AXIS) MEASUREMENT TEMPLATE ===")
    
    # 1. Check for 3D file
    try:
        # Load Mesh
        mesh = o3d.io.read_triangle_mesh(MESH_PATH)
        if mesh.is_empty():
            raise FileNotFoundError("Mesh file not found or empty.")
        print(f"Loaded 3D Mesh: {MESH_PATH}")
    except Exception as e:
        print("\n[!] CRITICAL: 3D FILE REQUIRED FOR Z-AXIS")
        print("To measure 'Z' (Depth), you cannot use just a JPG/PNG.")
        print("You must export the scan as .STL or .PLY from the IOS scanner.")
        print(f"Error: {e}")
        print("\n--- SIMULATION MODE ---")
        print("Simulating depth calculation for demonstration...")
        simulate_z_calculation()
        return

    # 2. Logic to project 2D mask onto 3D
    # (This requires camera intrinsic parameters to map Pixel (u,v) -> Point (x,y,z))
    # For this FYP, we will use a simplified Bounding Box approach on the mesh.

    print("Calculating mesh bounds...")
    aabb = mesh.get_axis_aligned_bounding_box()
    min_bound = aabb.get_min_bound()
    max_bound = aabb.get_max_bound()
    
    size_x = max_bound[0] - min_bound[0]
    size_y = max_bound[1] - min_bound[1]
    size_z = max_bound[2] - min_bound[2]

    print(f"\nTotal Scan Volume Dimensions:")
    print(f"X: {size_x:.2f} mm")
    print(f"Y: {size_y:.2f} mm")
    print(f"Z (Depth): {size_z:.2f} mm")

def simulate_z_calculation():
    """
    Simulates how the calculation works if the 3D file was present.
    """
    import random
    
    # Load the 2D mask to see what we detected
    mask_path = MASK_2D_PATH
    try:
        # Load mask (convert to class ID if it's the color version)
        mask_color = np.array(Image.open(mask_path).convert("RGB"))
        # Undercut logic: Red > 200
        is_undercut = (mask_color[:, :, 0] > 200) & (mask_color[:, :, 1] < 50)
        undercut_pixels = np.sum(is_undercut)
    except:
        undercut_pixels = 0

    if undercut_pixels == 0:
        print("No undercut detected in 2D mask. Cannot measure 3D depth.")
        return

    print(f"\nBased on 2D segmentation of {undercut_pixels} pixels:")
    
    # Simulated depth values (in a real scenario, these come from raycasting the mesh)
    min_depth = 1.2  # mm
    max_depth = 3.5  # mm
    avg_depth = (min_depth + max_depth) / 2
    
    print("-" * 30)
    print(f"Calculated Undercut Depth (Z-Axis):")
    print(f"Max Depth: {max_depth} mm")
    print(f"Avg Depth: {avg_depth:.2f} mm")
    print("-" * 30)
    print("NOTE: Real Z-values require the .STL/.PLY file from your scanner.")

if __name__ == "__main__":
    measure_z_axis()
