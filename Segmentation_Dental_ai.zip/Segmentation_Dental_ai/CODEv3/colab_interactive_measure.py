# ========== COLAB INTERACTIVE MEASUREMENT - PASTE THIS ENTIRE CODE ==========
# This is a self-contained version for Google Colab

"""
Interactive Tooth Measurement System for 17-Class Segmentation (Colab Version)
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage.feature import peak_local_max
import os
import datetime
import csv
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T

# ========== U-Net Model Definition (Inline for Colab) ==========
class UNet(nn.Module):
    def __init__(self, num_classes, in_channels=3, base_channels=64):
        super().__init__()
        self.enc1 = self.conv_block(in_channels, base_channels)
        self.enc2 = self.conv_block(base_channels, base_channels * 2)
        self.enc3 = self.conv_block(base_channels * 2, base_channels * 4)
        self.enc4 = self.conv_block(base_channels * 4, base_channels * 8)
        self.bottleneck = self.conv_block(base_channels * 8, base_channels * 16)
        self.upconv4 = nn.ConvTranspose2d(base_channels * 16, base_channels * 8, 2, stride=2)
        self.dec4 = self.conv_block(base_channels * 16, base_channels * 8)
        self.upconv3 = nn.ConvTranspose2d(base_channels * 8, base_channels * 4, 2, stride=2)
        self.dec3 = self.conv_block(base_channels * 8, base_channels * 4)
        self.upconv2 = nn.ConvTranspose2d(base_channels * 4, base_channels * 2, 2, stride=2)
        self.dec2 = self.conv_block(base_channels * 4, base_channels * 2)
        self.upconv1 = nn.ConvTranspose2d(base_channels * 2, base_channels, 2, stride=2)
        self.dec1 = self.conv_block(base_channels * 2, base_channels)
        self.outconv = nn.Conv2d(base_channels, num_classes, kernel_size=1)
        self.pool = nn.MaxPool2d(2, 2)
    
    def conv_block(self, in_ch, out_ch):
        return nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True)
        )
    
    def forward(self, x):
        enc1 = self.enc1(x)
        enc2 = self.enc2(self.pool(enc1))
        enc3 = self.enc3(self.pool(enc2))
        enc4 = self.enc4(self.pool(enc3))
        bottleneck = self.bottleneck(self.pool(enc4))
        dec4 = self.upconv4(bottleneck)
        dec4 = torch.cat([dec4, enc4], dim=1)
        dec4 = self.dec4(dec4)
        dec3 = self.upconv3(dec4)
        dec3 = torch.cat([dec3, enc3], dim=1)
        dec3 = self.dec3(dec3)
        dec2 = self.upconv2(dec3)
        dec2 = torch.cat([dec2, enc2], dim=1)
        dec2 = self.dec2(dec2)
        dec1 = self.upconv1(dec2)
        dec1 = torch.cat([dec1, enc1], dim=1)
        dec1 = self.dec1(dec1)
        return self.outconv(dec1)

print("✓ UNet model defined")

# ================= CONFIG =================
MODEL_PATH = "/content/best_unet_250epochs.pt"  # Colab path!
IMAGE_PATH = "/content/Segmentation-Dental-1/valid/FrontView11_png.rf.1e8bb31a2db5d1e1c1c6b83e6032ac9a.jpg"  # Update with your image
RESULTS_DIR = "/content/results"
CSV_PATH = "/content/measurements.csv"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NUM_CLASSES = 17
IMG_SIZE = 256
PIXEL_TO_MM = 0.05
Z_COORDINATE = 0.0

CLASS_NAMES = {i: f"teeth_{i+1}" if i > 0 else "teeth" for i in range(NUM_CLASSES)}

os.makedirs(RESULTS_DIR, exist_ok=True)

# Load model
print(f"Loading model from {MODEL_PATH}...")
model = UNet(num_classes=NUM_CLASSES).to(DEVICE)
state = torch.load(MODEL_PATH, map_location=DEVICE)
model.load_state_dict(state)
model.eval()
print(f"✓ Model loaded on {DEVICE}")

# Load image
img_pil = Image.open(IMAGE_PATH).convert("RGB")
orig_w, orig_h = img_pil.size
print(f"✓ Image loaded: {orig_w}x{orig_h}")

# Run inference
transform = T.Compose([
    T.Resize((IMG_SIZE, IMG_SIZE)),
    T.ToTensor(),
    T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

img_tensor = transform(img_pil).unsqueeze(0).to(DEVICE)

with torch.no_grad():
    logits = model(img_tensor)
    probs = F.softmax(logits, dim=1)
    pred_mask = logits.argmax(1)[0].cpu().numpy().astype(np.uint8)
    confidence_map = probs.max(1)[0][0].cpu().numpy()

print(f"✓ Inference complete")

# Resize mask to original
mask_resized = cv2.resize(pred_mask, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)
confidence_resized = cv2.resize(confidence_map, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)

# Visualize
img_rgb = np.array(img_pil)
h, w = img_rgb.shape[:2]

# Create colored overlay
unique_classes = np.unique(mask_resized)
print(f"Classes detected: {unique_classes}")

np.random.seed(42)
colors = np.random.randint(50, 255, (NUM_CLASSES + 1, 3), dtype=np.uint8)
colors[0] = [0, 0, 0]  # Background = black

vis_colored = colors[mask_resized]
vis_overlay = cv2.addWeighted(img_rgb, 0.5, vis_colored, 0.5, 0)

# Show result
plt.figure(figsize=(14, 10))
plt.imshow(vis_overlay)
plt.title(f"Segmentation Result - {len(unique_classes)-1} Classes Detected", fontsize=14)
plt.axis('off')
plt.show()

print(f"\n✓ Visualization complete!")
print(f"Classes found: {[CLASS_NAMES.get(c, f'class_{c}') for c in unique_classes if c > 0]}")
