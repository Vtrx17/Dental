"""
Interactive Tooth Measurement System for 16-Class Segmentation
Allows clicking on individual teeth to measure them with CSV export
Includes confidence scores and ML post-processing
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage.feature import peak_local_max
import os
import datetime
import csv
import torch
import torch.nn.functional as F
import torchvision.transforms as T
from models.unet_colab import UNet  # Use Colab-compatible architecture

# ================= CONFIG =================
# Model and paths
MODEL_PATH = "models/best_unet_250epochs.pt"  # NEW 250-epoch model!
# Use REAL validation image - works with 98% confidence!
IMAGE_PATH = "data/test/Undercut1.png"
RESULTS_DIR = "results/measurements"
CSV_PATH = "measurements.csv"

# Model config
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NUM_CLASSES = 17  # Updated: 17 classes from 250-epoch training
IMG_SIZE = 256

# Calibration (adjust based on your setup)
PIXEL_TO_MM = 0.05  # mm per pixel
Z_COORDINATE = 0.0  # For 2D images, set to 0; for 3D, implement depth estimation

# 17 tooth class names (updated for 250-epoch model)
CLASS_NAMES = {
    0: "teeth", 1: "teeth_2", 2: "teeth_3", 3: "teeth_4",
    4: "teeth_5", 5: "teeth_6", 6: "teeth_7", 7: "teeth_8",
    8: "teeth_9", 9: "teeth_10", 10: "teeth_11", 11: "teeth_12",
    12: "teeth_13", 13: "teeth_14", 14: "teeth_15", 15: "teeth_16",
    16: "teeth_17"  # Added for 17-class model
}

os.makedirs(RESULTS_DIR, exist_ok=True)
# ==========================================


def initialize_csv():
    """Create CSV file with headers if it doesn't exist"""
    if not os.path.exists(CSV_PATH):
        with open(CSV_PATH, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                'timestamp',
                'image_filename',
                'tooth_class',
                'surface_area_mm2',
                'centroid_x',
                'centroid_y',
                'centroid_z',
                'confidence',
                'width_mm',
                'height_mm',
                'perimeter_mm',
                'num_pixels'
            ])
        print(f"✓ Created CSV file: {CSV_PATH}")


def save_to_csv(data):
    """Append measurement data to CSV"""
    with open(CSV_PATH, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            data['timestamp'],
            data['image_filename'],
            data['tooth_class'],
            f"{data['surface_area_mm2']:.4f}",
            f"{data['centroid_x']:.2f}",
            f"{data['centroid_y']:.2f}",
            f"{data['centroid_z']:.2f}",
            f"{data['confidence']:.4f}",
            f"{data['width_mm']:.2f}",
            f"{data['height_mm']:.2f}",
            f"{data['perimeter_mm']:.2f}",
            data['num_pixels']
        ])


def load_model():
    """Load the 16-class U-Net model"""
    print(f"Loading model from {MODEL_PATH}...")
    model = UNet(num_classes=NUM_CLASSES, in_channels=3).to(DEVICE)
    state = torch.load(MODEL_PATH, map_location=DEVICE)
    model.load_state_dict(state)
    model.eval()
    print(f"✓ Model loaded on {DEVICE}")
    return model


def run_inference_with_confidence(model, img_pil, use_tta=True):
    """Run inference and return mask + confidence map
    
    Args:
        model: PyTorch model
        img_pil: PIL Image
        use_tta: Use Test-Time Augmentation (improves accuracy by ~2-5%)
    
    Returns:
        mask_np: Segmentation mask (H, W)
        confidence_np: Confidence map (H, W)
    """
    # Preprocess
    transform = T.Compose([
        T.Resize((IMG_SIZE, IMG_SIZE)),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    
    img_tensor = transform(img_pil).unsqueeze(0).to(DEVICE)
    
    if use_tta:
        # TEST-TIME AUGMENTATION for better accuracy
        print("  🔄 Using Test-Time Augmentation (4 predictions averaged)...")
        predictions = []
        
        # 1. Original
        with torch.no_grad():
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)
            predictions.append(probs)
        
        # 2. Horizontal flip
        img_flipped = torch.flip(img_tensor, dims=[3])
        with torch.no_grad():
            logits = model(img_flipped)
            probs = F.softmax(logits, dim=1)
            probs = torch.flip(probs, dims=[3])  # Flip back
            predictions.append(probs)
        
        # 3. Vertical flip
        img_flipped = torch.flip(img_tensor, dims=[2])
        with torch.no_grad():
            logits = model(img_flipped)
            probs = F.softmax(logits, dim=1)
            probs = torch.flip(probs, dims=[2])  # Flip back
            predictions.append(probs)
        
        # 4. Both flips
        img_flipped = torch.flip(img_tensor, dims=[2, 3])
        with torch.no_grad():
            logits = model(img_flipped)
            probs = F.softmax(logits, dim=1)
            probs = torch.flip(probs, dims=[2, 3])  # Flip back
            predictions.append(probs)
        
        # Average all predictions
        avg_probs = torch.stack(predictions).mean(dim=0)
        pred_mask = avg_probs.argmax(1)[0]
        confidence_map = avg_probs.max(1)[0][0]
        
    else:
        # Standard inference
        with torch.no_grad():
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)
            pred_mask = logits.argmax(1)[0]
            confidence_map = probs.max(1)[0][0]
    
    mask_np = pred_mask.cpu().numpy().astype(np.uint8)
    confidence_np = confidence_map.cpu().numpy().astype(np.float32)
    
    return mask_np, confidence_np


def apply_crf_postprocessing(img_rgb, mask):
    """
    Apply Conditional Random Field (CRF) for boundary refinement
    Optional: Install pydensecrf for this to work
    """
    try:
        import pydensecrf.densecrf as dcrf
        from pydensecrf.utils import unary_from_softmax
        
        # This is a placeholder - full CRF implementation would go here
        # For now, return original mask
        print("  (CRF post-processing available but not applied)")
        return mask
    except ImportError:
        # CRF not installed, skip
        return mask


def morphological_postprocessing(mask):
    """Apply morphological operations to clean up segmentation"""
    # Remove small noise
    kernel = np.ones((3, 3), np.uint8)
    mask_cleaned = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    
    # Fill holes
    mask_cleaned = cv2.morphologyEx(mask_cleaned, cv2.MORPH_CLOSE, kernel, iterations=1)
    
    return mask_cleaned


def segment_individual_teeth(mask, img_rgb):
    """
    Segment individual teeth by:
    1. Merging all tooth classes (1-15) into one "teeth" region
    2. Using watershed to separate individual teeth based on shape
    3. Ignoring class 0 (background)
    """
    print("\n🔬 Segmenting individual teeth using watershed...")
    
    # Calculate minimum area based on image size
    image_area = mask.shape[0] * mask.shape[1]
    min_tooth_area = int(image_area * 0.0008)  # At least 0.08% of image
    
    # Step 1: Create binary mask of ALL teeth (exclude class 0 = background)
    all_teeth_mask = (mask > 0).astype(np.uint8)  # All classes except 0
    
    total_tooth_pixels = np.sum(all_teeth_mask)
    print(f"  Total tooth pixels: {total_tooth_pixels} ({100*total_tooth_pixels/image_area:.1f}% of image)")
    
    if total_tooth_pixels < min_tooth_area:
        print("  ❌ No significant tooth region found!")
        return np.zeros_like(mask, dtype=np.int32), {}
    
    # Step 2: Clean up the mask
    kernel = np.ones((3, 3), np.uint8)
    all_teeth_mask = cv2.morphologyEx(all_teeth_mask, cv2.MORPH_OPEN, kernel, iterations=2)
    all_teeth_mask = cv2.morphologyEx(all_teeth_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    # Step 3: Distance transform to find tooth centers
    dist_transform = cv2.distanceTransform(all_teeth_mask, cv2.DIST_L2, 5)
    
    # Step 4: Find local maxima (each peak = one tooth)
    # ADJUSTED: More sensitive to detect individual teeth
    min_distance = max(30, int(np.sqrt(image_area) * 0.03))  # Reduced from 0.06
    print(f"  Using min_distance: {min_distance} pixels")
    
    coordinates = peak_local_max(
        dist_transform,
        min_distance=min_distance,
        threshold_abs=1.5,  # Lowered from 3.0 for more sensitivity
        exclude_border=True
    )
    
    num_teeth = len(coordinates)
    print(f"  Detected {num_teeth} tooth centers")
    
    if num_teeth == 0:
        print("  ⚠️  No tooth peaks found - treating all as one region")
        global_instance_map = np.zeros_like(mask, dtype=np.int32)
        global_instance_map[all_teeth_mask == 1] = 1
        instance_info = {
            1: {'class_id': 1, 'class_name': 'tooth_region'}
        }
        return global_instance_map, instance_info
    
    # Sanity check: typical human has 28-32 teeth
    if num_teeth > 35:
        print(f"  ⚠️  WARNING: Detected {num_teeth} teeth - likely over-segmented")
        print(f"  Keeping only the {35} strongest peaks")
        # Keep only strongest peaks
        peak_strengths = [dist_transform[int(y), int(x)] for y, x in coordinates]
        top_indices = np.argsort(peak_strengths)[-35:]
        coordinates = coordinates[top_indices]
        num_teeth = len(coordinates)
    
    # Step 5: Create markers from peaks
    markers = np.zeros_like(dist_transform, dtype=np.int32)
    for i, (y, x) in enumerate(coordinates):
        markers[int(y), int(x)] = i + 1
    
    # Step 6: Dilate markers to create seed regions
    kernel_dilate = np.ones((7, 7), np.uint8)
    for marker_id in range(1, num_teeth + 1):
        mask_single = (markers == marker_id).astype(np.uint8)
        dilated = cv2.dilate(mask_single, kernel_dilate, iterations=4)
        markers[dilated > 0] = marker_id
    
    # Step 7: Mark background (everything outside teeth)
    markers[all_teeth_mask == 0] = -1
    
    # Step 8: Apply watershed
    watershed_img = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
    markers = cv2.watershed(watershed_img, markers)
    
    # Step 9: Extract individual teeth with filtering
    global_instance_map = np.zeros_like(mask, dtype=np.int32)
    instance_info = {}
    current_id = 1
    
    unique_markers = np.unique(markers)
    valid_teeth = []
    
    # First pass: collect all valid teeth
    for m in unique_markers:
        if m <= 0:  # Skip background and borders
            continue
        
        seg_mask = (markers == m)
        seg_area = np.sum(seg_mask)
        
        # Filter out tiny segments
        if seg_area < min_tooth_area:
            continue
        
        # Calculate centroid for sorting
        y_coords, x_coords = np.where(seg_mask)
        centroid_x = x_coords.mean()
        centroid_y = y_coords.mean()
        
        valid_teeth.append({
            'marker': m,
            'mask': seg_mask,
            'area': seg_area,
            'centroid_x': centroid_x,
            'centroid_y': centroid_y
        })
    
    # Sort teeth by position (top-left to bottom-right)
    # This gives consistent numbering: top row first (left to right), then bottom row
    valid_teeth.sort(key=lambda t: (t['centroid_y'], t['centroid_x']))
    
    # Second pass: assign sequential tooth numbers
    for tooth_data in valid_teeth:
        seg_mask = tooth_data['mask']
        
        # Simple sequential numbering: Tooth 1, Tooth 2, etc.
        tooth_number = current_id
        
        # Assign to global map
        global_instance_map[seg_mask] = current_id
        instance_info[current_id] = {
            'class_id': 0,  # Not using class prediction
            'class_name': f"Tooth_{tooth_number}"  # Simple sequential naming
        }
        current_id += 1
    
    total_detected = current_id - 1
    print(f"✓ Total individual teeth segmented: {total_detected}")
    
    # Provide helpful feedback
    if total_detected < 8:
        print(f"  ℹ️  Only {total_detected} teeth detected - partial view?")
    elif total_detected > 16:
        print(f"  ⚠️  {total_detected} teeth detected - may include fragments")
    else:
        print(f"  ✅ Realistic tooth count detected")
    
    return global_instance_map, instance_info


def calculate_measurements(instance_mask, confidence_map):
    """Calculate measurements for a single tooth instance"""
    # Get pixels
    y_indices, x_indices = np.where(instance_mask)
    
    if len(y_indices) == 0:
        return None
    
    # Bounding box
    ymin, ymax = y_indices.min(), y_indices.max()
    xmin, xmax = x_indices.min(), x_indices.max()
    
    # Centroid
    centroid_y = y_indices.mean()
    centroid_x = x_indices.mean()
    
    # Dimensions
    width_px = xmax - xmin + 1
    height_px = ymax - ymin + 1
    width_mm = width_px * PIXEL_TO_MM
    height_mm = height_px * PIXEL_TO_MM
    
    # Surface area
    num_pixels = np.sum(instance_mask)
    area_mm2 = num_pixels * (PIXEL_TO_MM ** 2)
    
    # Perimeter
    contours, _ = cv2.findContours(instance_mask.astype(np.uint8), 
                                    cv2.RETR_EXTERNAL, 
                                    cv2.CHAIN_APPROX_SIMPLE)
    perimeter_px = cv2.arcLength(contours[0], True) if len(contours) > 0 else 0
    perimeter_mm = perimeter_px * PIXEL_TO_MM
    
    # Confidence (average confidence in this region)
    avg_confidence = confidence_map[instance_mask].mean()
    
    return {
        'centroid_x': centroid_x,
        'centroid_y': centroid_y,
        'centroid_z': Z_COORDINATE,
        'width_mm': width_mm,
        'height_mm': height_mm,
        'surface_area_mm2': area_mm2,
        'perimeter_mm': perimeter_mm,
        'num_pixels': int(num_pixels),
        'confidence': float(avg_confidence),
        'bbox': (xmin, ymin, xmax, ymax)
    }


def get_distinct_colors(num_colors):
    """Generate distinct colors for visualization"""
    np.random.seed(42)
    colors = []
    for i in range(num_colors):
        colors.append([
            np.random.randint(50, 255),
            np.random.randint(50, 255),
            np.random.randint(50, 255)
        ])
    return np.array(colors, dtype=np.uint8)


def interactive_measurement():
    """Main interactive measurement function"""
    print("=" * 70)
    print("INTERACTIVE 16-CLASS TOOTH MEASUREMENT SYSTEM")
    print("=" * 70)
    
    # Initialize CSV
    initialize_csv()
    
    # Load model
    model = load_model()
    
    # Load image
    try:
        img_pil = Image.open(IMAGE_PATH).convert("RGB")
        orig_w, orig_h = img_pil.size
        print(f"✓ Image loaded: {IMAGE_PATH} ({orig_w}x{orig_h})")
    except Exception as e:
        print(f"❌ Error loading image: {e}")
        return
    
    # Run inference
    print("\n🔍 Running inference...")
    mask, confidence_map = run_inference_with_confidence(model, img_pil)
    h_mask, w_mask = mask.shape
    print(f"✓ Inference complete: {w_mask}x{h_mask} mask")
    
    # Post-processing
    print("\n🧹 Applying post-processing...")
    mask = morphological_postprocessing(mask)
    # mask = apply_crf_postprocessing(img_rgb, mask)  # Optional
    
    # IMPORTANT: Resize mask UP to original image size for better visualization
    # This keeps the original image quality while applying the segmentation
    mask_resized = cv2.resize(mask, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)
    confidence_resized = cv2.resize(confidence_map, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)
    
    # Use original resolution image
    img_rgb = np.array(img_pil)
    h, w = img_rgb.shape[:2]
    
    print(f"✓ Resized mask to original resolution: {w}x{h}")
    
    # Segment individual teeth (on full resolution mask)
    instance_map, instance_info = segment_individual_teeth(mask_resized, img_rgb)
    
    num_instances = len(instance_info)
    if num_instances == 0:
        print("❌ No teeth detected!")
        return
    
    # Create visualization
    print("\n🎨 Creating visualization...")
    colors = get_distinct_colors(num_instances + 1)
    
    vis_colored = np.zeros((h, w, 3), dtype=np.uint8)
    for instance_id in range(1, num_instances + 1):
        vis_colored[instance_map == instance_id] = colors[instance_id]
    
    # Blend with original
    alpha = 0.5
    vis_overlay = cv2.addWeighted(img_rgb, 1 - alpha, vis_colored, alpha, 0)
    
    # Draw contours
    for instance_id in range(1, num_instances + 1):
        seg_mask = (instance_map == instance_id).astype(np.uint8)
        contours, _ = cv2.findContours(seg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(vis_overlay, contours, -1, (255, 255, 255), 1)
    
    # Interactive plot
    print("\n" + "=" * 70)
    print("INTERACTIVE MODE")
    print("=" * 70)
    print("📌 Click on any tooth to measure it")
    print("📊 Measurements will be saved to:", CSV_PATH)
    print("=" * 70 + "\n")
    
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.imshow(vis_overlay)
    ax.set_title(f"Interactive Measurement - {num_instances} Teeth Detected - Click to Measure", 
                 fontsize=14, fontweight='bold')
    ax.axis('off')
    
    # Click handler
    def onclick(event):
        if event.xdata is None or event.ydata is None:
            return
        
        x, y = int(event.xdata), int(event.ydata)
        if x >= w or y >= h or x < 0 or y < 0:
            return
        
        # Get clicked instance
        instance_id = instance_map[y, x]
        
        if instance_id == 0:
            print("⚠️  Clicked on background")
            return
        
        # Get tooth info
        info = instance_info[instance_id]
        class_name = info['class_name']
        
        print(f"\n{'='*60}")
        print(f"📏 Measuring: {class_name} (Instance #{instance_id})")
        print(f"{'='*60}")
        
        # Calculate measurements
        instance_mask = (instance_map == instance_id)
        measurements = calculate_measurements(instance_mask, confidence_resized)
        
        if measurements is None:
            print("❌ Error calculating measurements")
            return
        
        # Display results
        print(f"Surface Area:  {measurements['surface_area_mm2']:.2f} mm²")
        print(f"Width:         {measurements['width_mm']:.2f} mm")
        print(f"Height:        {measurements['height_mm']:.2f} mm")
        print(f"Perimeter:     {measurements['perimeter_mm']:.2f} mm")
        print(f"Centroid:      ({measurements['centroid_x']:.1f}, {measurements['centroid_y']:.1f}, {measurements['centroid_z']:.1f})")
        print(f"Confidence:    {measurements['confidence']:.2%}")
        print(f"Pixels:        {measurements['num_pixels']}")
        
        # Save to CSV
        csv_data = {
            'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'image_filename': os.path.basename(IMAGE_PATH),
            'tooth_class': class_name,
            **measurements
        }
        save_to_csv(csv_data)
        print(f"✓ Saved to {CSV_PATH}")
        
        # Save visualization
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{class_name}_{timestamp}.png"
        
        # Create highlighted image
        dim_factor = 0.3
        img_dimmed = (img_rgb.astype(np.float32) * dim_factor).astype(np.uint8)
        final_vis = img_dimmed.copy()
        final_vis[instance_mask] = img_rgb[instance_mask]
        
        # Crop to region
        xmin, ymin, xmax, ymax = measurements['bbox']
        pad = 30
        y1 = max(0, ymin - pad)
        y2 = min(h, ymax + pad)
        x1 = max(0, xmin - pad)
        x2 = min(w, xmax + pad)
        
        crop_vis = final_vis[y1:y2, x1:x2].copy()
        
        # Draw contour
        crop_mask = instance_mask[y1:y2, x1:x2].astype(np.uint8)
        contours, _ = cv2.findContours(crop_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(crop_vis, contours, -1, (0, 255, 255), 2)
        
        # Save
        img_path = os.path.join(RESULTS_DIR, filename)
        cv2.imwrite(img_path, cv2.cvtColor(crop_vis, cv2.COLOR_RGB2BGR))
        print(f"✓ Saved image: {img_path}")
        
        # Update plot
        bbox_rect = plt.Rectangle((xmin, ymin), xmax - xmin, ymax - ymin,
                                   linewidth=2, edgecolor='cyan', facecolor='none')
        ax.add_patch(bbox_rect)
        ax.text(xmin, ymin - 5, f"{class_name}\n{measurements['surface_area_mm2']:.1f}mm²",
                color='white', fontsize=9, backgroundcolor='black',
                bbox=dict(boxstyle='round', facecolor='black', alpha=0.7))
        fig.canvas.draw()
        
        print(f"{'='*60}\n")
    
    # Connect event
    cid = fig.canvas.mpl_connect('button_press_event', onclick)
    plt.tight_layout()
    plt.show()
    
    print("\n" + "=" * 70)
    print("✅ SESSION COMPLETE")
    print(f"📊 All measurements saved to: {CSV_PATH}")
    print("=" * 70)


if __name__ == "__main__":
    interactive_measurement()
