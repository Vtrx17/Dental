import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage.feature import peak_local_max
from scipy import ndimage
import os
import datetime

# ================= CONFIG =================
# We need the Original Image AND the Mask from the Inference step
# For now we use the static path, but in a real app this would be dynamic
IMAGE_PATH = "data/test/test_topview.png"
MASK_PATH = "results/batch_test/test_topview_mask.png"

# Camera calibration (mm per pixel) - Example value
PIXEL_TO_MM = 0.05 
# ==========================================

    # ... (Imports and Config remain same, start refactoring from interactive_measurement) ...

def get_distinct_colors(num_colors):
    """Generate distinct colors for visualization"""
    colors = []
    for i in range(num_colors):
        # Generate random bright colors
        c = np.random.randint(50, 255, size=3).tolist()
        colors.append(c)
    return np.array(colors, dtype=np.uint8)

def interactive_measurement():
    # 1. Load Images
    try:
        img_orig = cv2.imread(IMAGE_PATH)
        if img_orig is None: raise FileNotFoundError(IMAGE_PATH)
        img_orig = cv2.cvtColor(img_orig, cv2.COLOR_BGR2RGB)
        h_orig, w_orig = img_orig.shape[:2]
        
        # Load mask at NATIVE resolution (DON'T resize it!)
        mask_img = Image.open(MASK_PATH).convert("RGB")
        mask_color = np.array(mask_img)
        h_mask, w_mask = mask_color.shape[:2]
        
        print(f"Original image size: {h_orig}x{w_orig}")
        print(f"Mask size: {h_mask}x{w_mask}")
        
        # CRITICAL: Resize IMAGE to match MASK size (not the other way around)
        # This preserves the pure RGB colors in the mask
        img = cv2.resize(img_orig, (w_mask, h_mask), interpolation=cv2.INTER_LINEAR)
        print(f"Working with image resized to: {img.shape[:2]}")
        
        # Reconstruct ID mask from UNet output
        # Based on ACTUAL mask RGB values from batch_test:
        # Teeth: CYAN RGB(0, 165, 255) - from batch_test COLOR output
        # Background: GREEN RGB(0, 255, 0) - should NOT be processed
        mask = np.zeros(mask_color.shape[:2], dtype=np.uint8)
        
        # Tooth: CYAN (R=0, G=100-200 for cyan, B=255)
        is_tooth = (mask_color[:, :, 2] > 200) & (mask_color[:, :, 1] > 100) & (mask_color[:, :, 1] < 220) & (mask_color[:, :, 0] < 50)
        mask[is_tooth] = 1  # Tooth class
        
        # Gum: Orange-ish RGB(255, 165, 0) - if present
        is_gum = (mask_color[:, :, 0] > 200) & (mask_color[:, :, 1] > 100) & (mask_color[:, :, 1] < 200) & (mask_color[:, :, 2] < 100)
        mask[is_gum] = 2
        
        # Undercut: RED RGB(255, 0, 0) - if present
        is_undercut = (mask_color[:, :, 0] > 200) & (mask_color[:, :, 1] < 100) & (mask_color[:, :, 2] < 100)
        mask[is_undercut] = 3
        
        # GREEN pixels RGB(0,255,0) are left as 0 (background) and NOT processed by watershed
    except Exception as e:
        print(f"Error: {e}")
        return

    print("PRE-CALCULATING SEGMENTS (WATERSHED)...")
    
    # 2. Pre-Calculate Instance Map for ALL classes
    # We will build a 'global_instance_map' where 0=bg, and 1..N are unique instances across ALL classes
    global_instance_map = np.zeros_like(mask, dtype=np.int32)
    current_id_counter = 1
    
    # Mapping to remember which class each ID belongs to
    instance_class_map = {} 
    
    class_names = {1: "Tooth", 2: "Gum", 3: "Undercut"}  # Class 0 is background (not processed)
    
    for class_id in class_names.keys():
        binary_mask = (mask == class_id).astype(np.uint8)
        
        # --- Watershed Logic (USING PEAK_LOCAL_MAX) ---
        if np.sum(binary_mask) == 0:
            print(f"  No pixels for {class_names[class_id]}")
            continue
        
        # MORPHOLOGICAL EROSION: Shrink the mask to create gaps between touching teeth
        # This helps watershed separate individual teeth that are close together
        kernel_erosion = np.ones((3, 3), np.uint8)
        eroded_mask = cv2.erode(binary_mask, kernel_erosion, iterations=2)
        
        # If erosion removed too much, skip
        if np.sum(eroded_mask) < 100:
            print(f"  Erosion removed too much for {class_names[class_id]}, using original mask")
            eroded_mask = binary_mask
        
        # Compute distance transform on eroded mask
        dist_transform = cv2.distanceTransform(eroded_mask, cv2.DIST_L2, 5)
        
        # Find LOCAL MAXIMA (peaks)
        # Increased min_distance and threshold to avoid over-segmentation (detecting parts instead of whole teeth)
        coordinates = peak_local_max(dist_transform, min_distance=25, threshold_abs=1.0)
        
        print(f"  Found {len(coordinates)} peaks for {class_names[class_id]}")
        
        # Create markers from peaks
        markers = np.zeros_like(dist_transform, dtype=np.int32)
        for i, (y, x) in enumerate(coordinates):
            markers[y, x] = i + 1  # Assign unique IDs starting from 1
        
        # CRITICAL FIX: Dilate markers so they're not just single pixels
        # Use morphological dilation to give each marker a seed region
        kernel = np.ones((3, 3), np.uint8)
        for marker_id in range(1, len(coordinates) + 1):
            mask_single = (markers == marker_id).astype(np.uint8)
            dilated = cv2.dilate(mask_single, kernel, iterations=2)
            markers[dilated > 0] = marker_id
        
        # Mark background (unknown region gets marker 0, will be filled by watershed)
        markers[binary_mask == 0] = -1  # Mark definite background as -1
        
        # Apply Watershed
        watershed_img = img.copy()
        markers = cv2.watershed(watershed_img, markers)
        
        # Extract unique instances
        unique_markers = np.unique(markers)
        for m in unique_markers:
            if m <= 0: continue # Skip background (-1) and unknown (0)
            
            # Mask for JUST this segment
            seg_mask = (markers == m)
            if np.sum(seg_mask) < 20: continue # Noise filter
            
            # Assign to global map
            global_instance_map[seg_mask] = current_id_counter
            instance_class_map[current_id_counter] = class_name_str = class_names[class_id]
            current_id_counter += 1
            
    print(f"DONE. Found {current_id_counter-1} unique segments.")
    print("INSTRUCTIONS: Click on any colored segment to measure.")

    # 3. Create Visualization overlay
    # Generate random colors
    colors = get_distinct_colors(current_id_counter)
    
    # Colorize the instance map (working at mask resolution)
    h, w = img.shape[:2]
    vis_colored = np.zeros((h, w, 3), dtype=np.uint8)
    
    # Fast color mapping
    for i in range(1, current_id_counter):
        vis_colored[global_instance_map == i] = colors[i]
        
    # Blend with original
    alpha = 0.5
    vis_overlay = cv2.addWeighted(img, 1-alpha, vis_colored, alpha, 0)
    
    # Draw contours of ALL segments for clarity
    for i in range(1, current_id_counter):
        seg_mask = (global_instance_map == i).astype(np.uint8)
        contours, _ = cv2.findContours(seg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # Random contour color but bright
        cv2.drawContours(vis_overlay, contours, -1, (255, 255, 255), 1)

    # 4. Interactive Plot
    fig, ax = plt.subplots(figsize=(12, 10))
    ax.imshow(vis_overlay)
    ax.set_title(f"Interactive Measurement - {current_id_counter-1} Segments Detected")
    
    # Add a timestamp
    import datetime

    def draw_grid_on_image(img, pixel_to_mm=PIXEL_TO_MM):
        img_grid = img.copy()
        h, w = img_grid.shape[:2]
        px_per_mm = int(1 / pixel_to_mm)
        for x in range(0, w, px_per_mm): cv2.line(img_grid, (x, 0), (x, h), (255, 255, 255), 1, 1)
        for y in range(0, h, px_per_mm): cv2.line(img_grid, (0, y), (w, y), (255, 255, 255), 1, 1)
        return img_grid

    def onclick(event):
        if event.xdata is None or event.ydata is None: return
        x, y = int(event.xdata), int(event.ydata)
        h_work, w_work = img.shape[:2]
        if x >= w_work or y >= h_work: return

        # fast lookup
        clicked_id = global_instance_map[y, x]
        
        if clicked_id == 0:
            print("Clicked on background.")
            return
            
        class_name = instance_class_map.get(clicked_id, "Unknown")
        print(f"\nProcessing Seg ID: {clicked_id} ({class_name})...")
        
        single_blob_mask = (global_instance_map == clicked_id).astype(np.uint8)
        
        # Measurements
        y_indices, x_indices = np.where(single_blob_mask)
        ymin, ymax = y_indices.min(), y_indices.max()
        xmin, xmax = x_indices.min(), x_indices.max()
        
        # Re-calc dimensions
        width_px = xmax - xmin + 1
        height_px = ymax - ymin + 1
        width_mm = width_px * PIXEL_TO_MM
        height_mm = height_px * PIXEL_TO_MM
        area_mm2 = np.sum(single_blob_mask) * (PIXEL_TO_MM**2)
        
        # Create Report Image (Spotlight)
        dim_factor = 0.3
        img_dimmed = (img.astype(np.float32) * dim_factor).astype(np.uint8)
        img_highlight = img.copy()
        mask_bool = (single_blob_mask == 1)
        final_vis = img_dimmed.copy()
        final_vis[mask_bool] = img_highlight[mask_bool]
        
        pad = 50
        y1, y2 = max(0, ymin-pad), min(h_work, ymax+pad)
        x1, x2 = max(0, xmin-pad), min(w_work, xmax+pad)
        
        crop_vis = final_vis[y1:y2, x1:x2].copy()
        crop_vis = draw_grid_on_image(crop_vis)
        
        contours, _ = cv2.findContours(single_blob_mask[y1:y2, x1:x2], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(crop_vis, contours, -1, (0, 255, 255), 2)
        
        # Save
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename_base = f"selection_{class_name}_{timestamp}"
        img_path = os.path.join("results", f"{filename_base}.png")
        cv2.imwrite(img_path, cv2.cvtColor(crop_vis, cv2.COLOR_RGB2BGR))
        
        # Report
        with open(os.path.join("results", f"{filename_base}.txt"), "w") as f:
            f.write(f"MEASUREMENT REPORT\nType: {class_name}\nID: {clicked_id}\nWidth: {width_mm:.2f}mm\nHeight: {height_mm:.2f}mm\nArea: {area_mm2:.2f}mm2")
            
        # Update Plot
        rect = plt.Rectangle((xmin, ymin), width_px, height_px, linewidth=2, edgecolor='white', facecolor='none')
        ax.add_patch(rect)
        ax.text(xmin, ymin-10, f"{class_name} #{clicked_id}", color='white', fontsize=8, backgroundcolor='black')
        fig.canvas.draw()
        
        print(f"Dimensions: {width_mm:.2f}mm x {height_mm:.2f}mm (Saved)")

    cid = fig.canvas.mpl_connect('button_press_event', onclick)
    plt.show()

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    interactive_measurement()
