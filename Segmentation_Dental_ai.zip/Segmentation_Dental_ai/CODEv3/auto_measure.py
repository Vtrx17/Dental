import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage.feature import peak_local_max
from scipy import ndimage
import os
import datetime

# ================= CONFIG =================
IMAGE_PATH = "data/test/Undercut1.png"
MASK_PATH = "results/Undercut1_mask_unet.png"
PIXEL_TO_MM = 0.05 
RESULTS_DIR = "results/auto_reports"
# ==========================================

def draw_grid_on_image(img, pixel_to_mm=PIXEL_TO_MM):
    """Draws a 1mm x 1mm grid on the image."""
    img_grid = img.copy()
    h, w = img_grid.shape[:2]
    px_per_mm = int(1 / pixel_to_mm)
    
    # Draw vertical lines
    for x in range(0, w, px_per_mm):
        cv2.line(img_grid, (x, 0), (x, h), (255, 255, 255), 1, 1)
        
    # Draw horizontal lines
    for y in range(0, h, px_per_mm):
        cv2.line(img_grid, (0, y), (w, y), (255, 255, 255), 1, 1)

    return img_grid

def auto_measure():
    print("=== STARTING AUTO-MEASUREMENT SIMULATION ===")
    os.makedirs(RESULTS_DIR, exist_ok=True)

    # 1. Load Images
    try:
        img = cv2.imread(IMAGE_PATH)
        if img is None: raise FileNotFoundError(IMAGE_PATH)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Get Original Dimensions
        h_orig, w_orig = img.shape[:2]
        
        mask_img = Image.open(MASK_PATH).convert("RGB")
        # RESIZE MASK TO MATCH ORIGINAL IMAGE (Crucial Fix)
        mask_img = mask_img.resize((w_orig, h_orig), resample=Image.NEAREST)
        mask_color = np.array(mask_img)
        
        # Reconstruct ID mask from UNet output
        # Background is GREEN (0, 255, 0)
        # Tooth is CYAN (0, 165, 255)
        mask = np.zeros(mask_color.shape[:2], dtype=np.uint8)
        
        # Tooth: Cyan (R=0, G~165, B=255) - must have high B AND moderate G, NOT extreme G
        is_tooth = (mask_color[:, :, 2] > 200) & (mask_color[:, :, 1] > 100) & (mask_color[:, :, 1] < 220) & (mask_color[:, :, 0] < 50)
        mask[is_tooth] = 0
        
        # Gum: Orange-ish (if present)
        is_gum = (mask_color[:, :, 0] > 200) & (mask_color[:, :, 1] > 100) & (mask_color[:, :, 1] < 200) & (mask_color[:, :, 2] < 100)
        mask[is_gum] = 1
        
        # Undercut: Red (if present)
        is_undercut = (mask_color[:, :, 0] > 200) & (mask_color[:, :, 1] < 100) & (mask_color[:, :, 2] < 100)
        mask[is_undercut] = 2
        
        # Everything else (green background etc.) stays as background (not assigned)
        
    except Exception as e:
        print(f"Error loading files: {e}")
        return

    # 2. Iterate through all classes
    class_names = {0: "Tooth", 1: "Gum", 2: "Undercut"}
    
    total_segments = 0
    
    for class_id, class_name in class_names.items():
        print(f"\nAnalyzing Class: {class_name}...")
        
        # --- INSTANCE SEPARATION LOGIC (Watershed) ---
        binary_mask = (mask == class_id).astype(np.uint8)
        
        # --- Watershed Logic (USING PEAK_LOCAL_MAX) ---
        # NO morphology - it was eliminating all pixels after resize!
        binary_mask = (mask == class_id).astype(np.uint8)
        
        if np.sum(binary_mask) == 0:
            print(f"  No pixels for {class_name}")
            continue
        
        # Compute distance transform directly
        dist_transform = cv2.distanceTransform(binary_mask, cv2.DIST_L2, 5)
        
        # Find LOCAL MAXIMA (peaks)
        # Lowered min_distance to 15 and threshold to 0.5 for better detection
        coordinates = peak_local_max(dist_transform, min_distance=15, threshold_abs=0.5)
        
        print(f"  Found {len(coordinates)} peaks for {class_name}")
        
        # Create markers from peaks
        markers = np.zeros_like(dist_transform, dtype=np.int32)
        for i, (y, x) in enumerate(coordinates):
            markers[y, x] = i + 2  # Start from 2 (1 is background)
        
        # Dilate markers slightly
        markers = ndimage.label(markers > 0)[0]
        markers = markers + 1  # Shift so background is 1
        
        # Mark background
        markers[binary_mask == 0] = 1
        
        # Apply Watershed
        watershed_img = img.copy()
        markers = cv2.watershed(watershed_img, markers)
        
        # Get unique instances (skip 0=boundary/unknown, 1=background)
        unique_instances = np.unique(markers)
        
        for instance_id in unique_instances:
            if instance_id <= 1: continue # Skip bg/boundary
            
            single_blob_mask = (markers == instance_id).astype(np.uint8)
            
            # Simple noise filter
            if np.sum(single_blob_mask) < 50: continue 
            
            total_segments += 1
            
            # --- MEASUREMENT LOGIC ---
            y_indices, x_indices = np.where(single_blob_mask)
            ymin, ymax = y_indices.min(), y_indices.max()
            xmin, xmax = x_indices.min(), x_indices.max()
            
            width_px = xmax - xmin + 1
            height_px = ymax - ymin + 1
            area_px = np.sum(single_blob_mask)
            
            width_mm = width_px * PIXEL_TO_MM
            height_mm = height_px * PIXEL_TO_MM
            area_mm2 = area_px * (PIXEL_TO_MM**2)
            
            # --- GENERATE REPORT FIGURE (SPOTLIGHT STYLE) ---
            # 1. Create Layout
            # Background: DImmed original image (Shadow effect)
            dim_factor = 0.3
            img_dimmed = (img.astype(np.float32) * dim_factor).astype(np.uint8)
            
            # Foreground: Original brightness for the SELECTED segment only
            img_highlight = img.copy()
            
            # Create a mask for brightness combination
            # anywhere single_blob_mask is True, use img_highlight, else img_dimmed
            mask_bool = (single_blob_mask == 1)
            
            final_vis = img_dimmed.copy()
            final_vis[mask_bool] = img_highlight[mask_bool]
            
            # 2. Add Grid
            pad = 50 
            h, w = mask.shape
            y1, y2 = max(0, ymin-pad), min(h, ymax+pad)
            x1, x2 = max(0, xmin-pad), min(w, xmax+pad)
            
            # Crop to context
            crop_vis = final_vis[y1:y2, x1:x2].copy()
            crop_vis = draw_grid_on_image(crop_vis)
            
            # Draw Contours
            crop_mask = single_blob_mask[y1:y2, x1:x2]
            contours, _ = cv2.findContours(crop_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            color = (0, 255, 255) if class_id == 0 else (255, 0, 0) # Cyan or Red
            cv2.drawContours(crop_vis, contours, -1, color, 2)

            # Save Files
            blob_uid = f"{class_name}_seg{instance_id}"
            img_filename = f"{blob_uid}.png"
            img_path = os.path.join(RESULTS_DIR, img_filename)
            cv2.imwrite(img_path, cv2.cvtColor(crop_vis, cv2.COLOR_RGB2BGR))
            
            report_filename = f"{blob_uid}.txt"
            report_path = os.path.join(RESULTS_DIR, report_filename)
            
            with open(report_path, "w") as f:
                f.write(f"AUTO-GENERATED SEGMENT REPORT\n")
                f.write(f"=============================\n")
                f.write(f"Type: {class_name}\n")
                f.write(f"Segment ID: {instance_id}\n")
                f.write(f"Grid: 1.0mm\n\n")
                f.write(f"Width:  {width_mm:.2f} mm\n")
                f.write(f"Height: {height_mm:.2f} mm\n")
                f.write(f"Area:   {area_mm2:.2f} mm2\n")
                f.write(f"\nVISUALIZATION INFO:\n")
                f.write(f"- Bright Area: Selected Segment\n")
                f.write(f"- Dark Area: Surrounding Context\n")
                f.write(f"- Grid Lines: 1mm spacing\n")

            print(f"  -> Processed Segment {instance_id}: {width_mm:.2f}mm x {height_mm:.2f}mm (Saved)")

    print(f"\nCompleted! Processed {total_segments} segments.")
    print(f"Check the '{RESULTS_DIR}' folder for all reports.")

if __name__ == "__main__":
    auto_measure()
