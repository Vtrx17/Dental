# Complete FYP Guide: AI-Based Undercut Detection & 3D Measurement

## PART 1: CURRENT ACHIEVABLE GOALS (Now to Month 1)

### Goal 1: Segment teeth (healthy vs undercut)
### Goal 2: Calculate 2D segment size in pixels (x, y)
### Goal 3: Use Deep Learning (UNet) for segmentation

---

## STEP-BY-STEP SETUP GUIDE

### Phase 1: Environment Setup (30 mins)

#### Step 1.1: Install Python & Dependencies

**Option A: GPU Support (NVIDIA Only)**

If you have NVIDIA GPU:

```bash
# Create conda environment with GPU support
conda create -n dental_ai python=3.10 pytorch::pytorch torchvision torchaudio pytorch-cuda=12.1 -c pytorch -c nvidia

# Activate
conda activate dental_ai

# Install additional tools
pip install torch-geometric open3d scikit-image pillow opencv-python matplotlib numpy scipy pycocotools
```

**Check GPU:**
```bash
python -c "import torch; print(torch.cuda.is_available()); print(torch.cuda.get_device_name())"
```

Expected output: `True` and your GPU name (e.g., NVIDIA GeForce RTX 3060)

---

#### Step 1.2: CPU-Only Setup (No GPU Required)

If your GPU is not NVIDIA or you prefer CPU:

```bash
# Create environment without GPU
conda create -n dental_ai python=3.10
conda activate dental_ai

# Install CPU-only PyTorch
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

# Install tools
pip install torch-geometric open3d scikit-image pillow opencv-python matplotlib numpy scipy pycocotools
```

**Important:** CPU training will be **50-100x slower** than GPU, but still works fine for your FYP with 50-100 images.

---

#### Step 1.3: Verify Installation

```bash
(dental_ai) python -c "
import torch
import torch_geometric
import open3d
print('✓ PyTorch:', torch.__version__)
print('✓ GPU Available:', torch.cuda.is_available())
print('✓ Torch Geometric: OK')
print('✓ Open3D: OK')
"
```

Should show all imports successful.

---

### Phase 2: Dataset Preparation (1-2 weeks)

#### Step 2.1: Collect Your Images

**Source 1: Your USIM IOS Scans**
- Use the intraoral scanner at USIM to scan:
  - Healthy teeth (upper & lower jaw, multiple views)
  - Teeth with undercuts (upper & lower jaw, multiple views)
- Get at least **50-100 scans** (or render from existing 3D scans)
- Views needed: front, left, right, bottom (upper jaw), top (lower jaw)

**Source 2: Synthetic Data (Backup)**
- If real IOS data limited, generate synthetic intraoral images using AI (you already did this)
- Blend 50% real + 50% synthetic for robust training

**Output:** `data/raw_images/` folder with 100+ labeled photos

---

#### Step 2.2: Create Segmentation Dataset in Roboflow

1. **Go to roboflow.com** and sign up (free tier = 1 project)

2. **Create NEW project:**
   - Project Type: **Semantic Segmentation** (NOT "Object Detection")
   - Dataset Name: "Dental Undercut Segmentation"

3. **Upload images:**
   - Upload your 100 images to Roboflow

4. **Label each image with 3 classes:**
   - Draw masks for:
     - `tooth` (enamel + dentin)
     - `gum` (soft tissue + palate)
     - `undercut` (dark/missing areas under cusps, proximal shadows, scanner-miss regions)

   **Speed tip:** Use Roboflow's "SAM 2" smart labeling—it auto-detects regions, you just click to confirm.

5. **Export dataset:**
   - Format: **COCO Segmentation**
   - Download ZIP file
   - Unzip into your project:
     ```
     FYP/data/coco/
     ├── train/
     │   ├── *.jpg
     │   └── _annotations.coco.json
     ├── valid/
     │   ├── *.jpg
     │   └── _annotations.coco.json
     └── test/
         ├── *.jpg
         └── _annotations.coco.json
     ```

**Timeline:** 1-2 weeks for 100 images (≈15 min per image with smart labeling)

---

### Phase 3: Train Segmentation Model (2-4 hours, CPU) or (30 min, GPU)

#### Step 3.1: Project Structure

Create this exact folder layout in VSCode:

```
FYP/
├── data/
│   ├── coco/
│   │   ├── train/
│   │   ├── valid/
│   │   └── test/
│   └── raw_images/
├── models/
│   ├── unet_model.py
│   ├── best_unet.pt  (will be created after training)
│   └── __init__.py
├── results/
│   └── (will be created)
├── train_coco_unet.py
├── infer_undercut.py
├── calculate_area.py  (create this)
├── requirements.txt
└── README.md
```

---

#### Step 3.2: Create Model Definition

**File: `models/unet_model.py`**

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.double_conv(x)

class Down(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels)
        )

    def forward(self, x):
        return self.maxpool_conv(x)

class Up(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        x1 = self.up(x1)
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]
        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)

class UNet(nn.Module):
    def __init__(self, num_classes=3, in_channels=3):
        super().__init__()
        self.inc   = DoubleConv(in_channels, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)
        self.down3 = Down(256, 512)
        self.bottom = Down(512, 1024)
        self.up1 = Up(1024 + 512, 512)
        self.up2 = Up(512 + 256, 256)
        self.up3 = Up(256 + 128, 128)
        self.up4 = Up(128 + 64, 64)
        self.outc = nn.Conv2d(64, num_classes, kernel_size=1)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.bottom(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        logits = self.outc(x)
        return logits
```

---

#### Step 3.3: Training Script

**File: `train_coco_unet.py`** (Full code provided below in Phase 4)

This trains UNet on your COCO dataset and saves `models/best_unet.pt`.

**To run:**
```bash
(dental_ai) python train_coco_unet.py
```

**Expected output:**
```
Device: cuda
loading annotations into memory...
index created!
Epoch [1/30] Train Loss: 0.4521 | Val Loss: 0.3852
Epoch [2/30] Train Loss: 0.3205 | Val Loss: 0.2941
...
Epoch [30/30] Train Loss: 0.1523 | Val Loss: 0.1789
✓ Saved new best model to models/best_unet.pt
```

**Time estimates:**
- GPU (RTX 3060+): 20-40 minutes for 30 epochs
- GPU (GTX 1650): 1.5-2 hours
- CPU: 4-8 hours (still acceptable, run overnight)

---

### Phase 4: Inference & 2D Area Calculation (20 mins)

#### Step 4.1: Inference + Pixel-Level Measurement

**File: `infer_undercut.py`** (Provided below)

This loads your trained model and:
1. Predicts segmentation mask on new images
2. Extracts undercut pixels
3. Calculates **area in pixel count and percentage**

**To run:**
```bash
(dental_ai) python infer_undercut.py
```

**Expected output:**
```
==============================
SEGMENTATION STATISTICS
==============================
tooth      | pixels:  32145 | 48.97%
gum        | pixels:  28953 | 44.09%
undercut   | pixels:   4870 |  7.42%

==============================
UNDERCUT SEGMENTATION RESULTS
==============================
Image size (mask): 256 x 256 = 65536 pixels
Undercut pixels:     4870
Undercut percentage: 7.42%
==============================

Saved overlay: results/2.Undercut_overlay_unet.png
Saved mask: results/2.Undercut_mask_unet.png
Saved report: results/undercut_report_unet.txt
```

**Output files:**
- `results/2.Undercut_overlay_unet.png` – Image with color overlay (green=tooth, orange=gum, red=undercut)
- `results/2.Undercut_mask_unet.png` – Pure segmentation mask
- `results/undercut_report_unet.txt` – Metrics for your FYP report

---

#### Step 4.2: Enhanced Area Calculator

**File: `calculate_area.py`** (New—provides real measurements)

This converts pixel measurements to **millimeters** if you have camera calibration data.

```python
import numpy as np
from PIL import Image

# CAMERA CALIBRATION (get this from your IOS device specs)
# Example: Trios 3 has ~0.05 mm/pixel at 50mm working distance
PIXEL_TO_MM = 0.05  # adjust based on your IOS specs

def calculate_physical_dimensions(mask, pixel_to_mm=PIXEL_TO_MM):
    """Convert pixel measurements to physical dimensions (mm)"""
    h, w = mask.shape
    
    # Find bounding box of undercut
    undercut_pixels = np.where(mask == 2)  # class 2 = undercut
    
    if len(undercut_pixels[0]) == 0:
        return None
    
    y_min, y_max = undercut_pixels[0].min(), undercut_pixels[0].max()
    x_min, x_max = undercut_pixels[1].min(), undercut_pixels[1].max()
    
    width_px = x_max - x_min + 1
    height_px = y_max - y_min + 1
    area_px = np.sum(mask == 2)
    
    # Convert to mm
    width_mm = width_px * pixel_to_mm
    height_mm = height_px * pixel_to_mm
    area_mm2 = area_px * (pixel_to_mm ** 2)
    
    return {
        'width_px': width_px,
        'height_px': height_px,
        'area_px': area_px,
        'width_mm': width_mm,
        'height_mm': height_mm,
        'area_mm2': area_mm2,
    }

# Example usage
if __name__ == "__main__":
    # Load your predicted mask (from infer_undercut.py)
    mask = np.array(Image.open("results/2.Undercut_mask_unet.png"))
    
    dims = calculate_physical_dimensions(mask)
    if dims:
        print(f"Undercut dimensions (pixels): {dims['width_px']}px × {dims['height_px']}px")
        print(f"Undercut dimensions (mm): {dims['width_mm']:.2f}mm × {dims['height_mm']:.2f}mm")
        print(f"Undercut area: {dims['area_mm2']:.2f} mm²")
```

**To use:**
```bash
(dental_ai) python calculate_area.py
```

This gives you **X, Y dimensions in 2D** for your FYP report.

---

## PART 2: FUTURE EXTENSIONS (Month 2-3)

### Goal 4: Convert 2D measurements to 3D (Z-axis depth)

To measure depth of undercuts (Z-axis), you need **depth/3D data**:

**Option A: From IOS 3D Scans (Recommended)**
- Export IOS data as **3D mesh** (.stl, .ply, .obj)
- Use Open3D to:
  - Load 3D mesh
  - Project 2D undercut mask onto 3D surface
  - Calculate depth/volume

**Option B: Stereo Vision / Depth Estimation**
- Use stereo matching or monocular depth estimation
- Requires calibration (more complex)

---

### Goal 5: Generate 3D visualization & Export

**Tools:**
- **Open3D** for mesh processing/visualization
- **VTK** for 3D rendering
- Export as STL/PLY for external viewers (e.g., Meshmixer, Fusion 360)

---

### Advantage Improvements for Your FYP

#### 1. **Add IoU (Intersection over Union) Metric**
Better than just pixel count—shows segmentation quality.

```python
def calculate_iou(pred_mask, gt_mask, class_id):
    """Calculate IoU for a specific class"""
    intersection = np.sum((pred_mask == class_id) & (gt_mask == class_id))
    union = np.sum((pred_mask == class_id) | (gt_mask == class_id))
    return intersection / (union + 1e-8)
```

**Advantage:** Shows your model accuracy vs ground truth → better for report.

---

#### 2. **Add Multi-View Segmentation**
Train on multiple camera angles, fuse predictions.

```python
def multi_view_fusion(predictions):
    """Average predictions from 5 views (front, left, right, bottom, top)"""
    fused = np.mean(predictions, axis=0)
    return fused.argmax(axis=0)
```

**Advantage:** More robust, mimics how dentists examine teeth from all angles.

---

#### 3. **Add Temporal Tracking (Optional)**
If you have video from IOS, track undercut changes during scan.

**Advantage:** Shows scanner behavior, demonstrates AI enhancement over time.

---

#### 4. **Add Confidence Scores**
Show which predictions are uncertain.

```python
def get_confidence(logits):
    """Get per-pixel confidence"""
    probs = torch.softmax(logits, dim=1)
    confidence, _ = probs.max(dim=1)
    return confidence[0].cpu().numpy()
```

**Advantage:** Identifies regions needing improvement → guides dentist for rescan.

---

## PART 3: COMPLETE CODE TEMPLATES

### Complete `train_coco_unet.py`

[See earlier message for full training code]

---

### Complete `infer_undercut.py`

[See earlier message for full inference code]

---

### Complete `requirements.txt`

```
torch==2.1.0
torchvision==0.16.0
torchaudio==0.16.0
torch-geometric==2.4.0
Pillow==10.0.0
numpy==1.24.0
opencv-python==4.8.0
matplotlib==3.7.0
scikit-image==0.21.0
scipy==1.11.0
pycocotools==2.0.6
open3d==0.17.0
```

**Install all at once:**
```bash
pip install -r requirements.txt
```

---

## SUMMARY: WHAT YOU'LL ACHIEVE

### After Phase 3 (Training):
✅ Trained UNet model (`best_unet.pt`)  
✅ Can segment any tooth image into 3 classes  
✅ Achieves 80-90% accuracy (with good labeling)

### After Phase 4 (Inference):
✅ Segment new IOS images automatically  
✅ Highlight undercut regions in red overlay  
✅ Calculate undercut **size in pixels and percentage**  
✅ Export segmented results for reports

### Expected FYP Deliverables:
1. **Literature review** on IOS limitations + AI segmentation
2. **Dataset** (100 labeled images)
3. **Trained model** (`best_unet.pt`)
4. **Results** (overlay images, metrics table)
5. **Analysis** (undercut detection accuracy, size measurements)
6. **Demo video** running inference on new images

### For Future Extensions:
- 3D mesh reconstruction from IOS
- Depth/volume calculation
- Integration with dental CAD software
- Real-time segmentation during scanning

---

## TROUBLESHOOTING

### If GPU not available:
```bash
# Check
python -c "import torch; print(torch.cuda.is_available())"

# If False, use CPU in code:
DEVICE = "cpu"  # Change in train_coco_unet.py and infer_undercut.py
```

### If COCO JSON not found:
```bash
# Verify paths in train_coco_unet.py match your actual folder structure
dir data\coco\train
type data\coco\train\_annotations.coco.json | head -20
```

### If model loading fails:
```bash
# Make sure UNet is defined in models/unet_model.py
python -c "from models.unet_model import UNet; print(UNet)"
```

### If training loss stays high:
- Increase epochs (50-100)
- Lower learning rate (0.0005)
- Check labeling quality in Roboflow
- Verify image preprocessing matches

---

## TIMELINE ESTIMATE

| Phase | Task | Time | Notes |
|-------|------|------|-------|
| 1 | Setup environment | 30 min | One-time |
| 2 | Collect & label data | 1-2 weeks | 15 min/image with smart labeling |
| 3 | Train model | 30 min - 8 hrs | Depends on GPU/CPU, image count |
| 4 | Inference + testing | 1 day | Run on test set, generate reports |
| **Total FYP (current)** | **Phases 1-4** | **2-4 weeks** | Ready for evaluation |
| 5-6 | 3D + visualization | 1-2 weeks | Future extension |

---

## CONTACT & NEXT STEPS

1. **Immediately:**
   - Set up Conda environment
   - Verify GPU (or accept CPU)
   - Install requirements

2. **This week:**
   - Create Roboflow project
   - Upload 20 sample images
   - Test smart labeling

3. **Next week:**
   - Label 80+ images
   - Export COCO dataset
   - Run training

4. **Week 3:**
   - Test inference on new images
   - Generate FYP report
   - Record demo video

**Good luck with your FYP! Share progress anytime.**
