import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import torch
import torchvision.transforms as T
from models.unet_model import UNet

# ================= CONFIG =================
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_PATH = "models/best_unet.pt"
DATA_DIR = "data/test"
RESULTS_DIR = "results/multiview"
IMG_SIZE = 256
NUM_CLASSES = 3
# ==========================================

def load_model():
    model = UNet(num_classes=NUM_CLASSES, in_channels=3).to(DEVICE)
    state = torch.load(MODEL_PATH, map_location=DEVICE)
    model.load_state_dict(state)
    model.eval()
    return model

def process_image(model, img_path):
    # Load
    img_pil = Image.open(img_path).convert("RGB")
    orig_w, orig_h = img_pil.size
    
    # Preprocess
    transform = T.Compose([
        T.Resize((IMG_SIZE, IMG_SIZE)),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    img_tensor = transform(img_pil).unsqueeze(0).to(DEVICE)
    
    # Inference
    with torch.no_grad():
        logits = model(img_tensor)
        pred_mask = logits.argmax(1)[0].cpu().numpy().astype(np.uint8)
        
    # Resize mask back to original size for display
    # (Nearest neighbor to keep class IDs)
    pred_mask_pil = Image.fromarray(pred_mask).resize((orig_w, orig_h), resample=Image.NEAREST)
    pred_mask_full = np.array(pred_mask_pil)
    
    return np.array(img_pil), pred_mask_full

def create_overlay(img, mask):
    h, w, _ = img.shape
    
    # Colors: 0=Green(Tooth), 1=Orange(Gum), 2=Red(Undercut)
    color_mask = np.zeros_like(img)
    color_mask[mask == 0] = [0, 255, 0]    # Tooth
    color_mask[mask == 1] = [255, 165, 0]  # Gum
    color_mask[mask == 2] = [255, 0, 0]    # Undercut
    
    # Blend
    alpha = 0.4
    overlay = cv2.addWeighted(img, 1-alpha, color_mask, alpha, 0)
    
    # Add contours for structure
    # Tooth Contours (Cyan)
    contours, _ = cv2.findContours((mask == 0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, (0, 255, 255), 2)
    
    # Undercut Contours (White)
    contours, _ = cv2.findContours((mask == 2).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, (255, 255, 255), 2)
    
    return overlay

def run_multiview_analysis():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    model = load_model()
    
    # Defined views
    views = ["front", "left", "right", "upper", "lower"]
    
    results = {}
    
    print(f"Processing {len(views)} views...")
    
    for view in views:
        filename = f"{view}.png"
        path = os.path.join(DATA_DIR, filename)
        
        if not os.path.exists(path):
            print(f"Warning: {filename} not found. Skipping.")
            results[view] = None
            continue
            
        print(f"  - Analyzing {view} view...")
        img, mask = process_image(model, path)
        overlay = create_overlay(img, mask)
        
        # Calculate stats
        undercut_pixels = np.sum(mask == 2)
        total_pixels = mask.size
        pct = (undercut_pixels / total_pixels) * 100
        
        results[view] = {
            "img": img,
            "overlay": overlay,
            "pct": pct
        }
        
        # Save individual result
        cv2.imwrite(os.path.join(RESULTS_DIR, f"{view}_result.png"), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR))

    # Create Dashboard (Grid View)
    print("\nCreating Multi-View Dashboard...")
    
    # Setup matplotlib figure
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    axes = axes.flatten()
    
    # Map views to specific slots
    # Slot 0: Front, 1: Left, 3: Right (Middle row)
    # Slot 4: Upper, 5: Lower
    
    view_map = {
        "front": 1, # Top Middle
        "left": 3,  # Bottom Left
        "right": 5, # Bottom Right
        "upper": 0, # Top Left
        "lower": 2  # Top Right
    }
    # Wait, let's do a standard dental layout:
    #      [Upper] [Front] [Lower]
    #      [Left]  [Stats] [Right]
    
    layout_indices = {
        "upper": 0, "front": 1, "lower": 2,
        "left": 3, "right": 5
    }

    # Title
    fig.suptitle("Multi-View Dental Structure & Undercut Analysis", fontsize=16)

    for view, idx in layout_indices.items():
        ax = axes[idx]
        if results.get(view):
            res = results[view]
            ax.imshow(res["overlay"])
            ax.set_title(f"{view.upper()} VIEW\nUndercut: {res['pct']:.2f}%")
            ax.axis('off')
        else:
            ax.text(0.5, 0.5, "Image Not Found", ha='center')
            ax.axis('off')

    # Central Stats Panel (Index 4)
    stat_ax = axes[4]
    stat_ax.axis('off')
    stat_text = "SUMMARY REPORT\n\n"
    for view in views:
        if results.get(view):
            stat_text += f"{view.upper()}: {results[view]['pct']:.2f}% Undercut\n"
        else:
            stat_text += f"{view.upper()}: N/A\n"
    
    stat_ax.text(0.1, 0.5, stat_text, fontsize=12, va='center')

    # Save Image
    out_path = os.path.join(RESULTS_DIR, "Dashboard_Analysis.png")
    plt.tight_layout()
    plt.savefig(out_path)
    print(f"✓ Dashboard saved to: {out_path}")
    
    # Save Text Report
    txt_path = os.path.join(RESULTS_DIR, "multiview_report.txt")
    with open(txt_path, "w") as f:
        f.write("MULTI-VIEW UNDERCUT ANALYSIS REPORT\n")
        f.write("===================================\n")
        f.write(f"Model ID: {MODEL_PATH}\n\n")
        f.write(stat_text)
        f.write("\n===================================\n")
        f.write("Note: This analysis assumes each view is pre-calibrated.\n")
    print(f"✓ Text Report saved to: {txt_path}")
    
    # Show it
    plt.show()

if __name__ == "__main__":
    run_multiview_analysis()
