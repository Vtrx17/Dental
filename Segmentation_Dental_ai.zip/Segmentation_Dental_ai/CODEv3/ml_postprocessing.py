"""
Machine Learning Post-Processing Methods for Tooth Segmentation
Provides advanced ML techniques to improve segmentation accuracy
"""
import numpy as np
import cv2
import torch
import torch.nn.functional as F


# ============ METHOD 1: Test-Time Augmentation (TTA) ============

def test_time_augmentation(model, img_tensor, device='cuda'):
    """
    Apply Test-Time Augmentation to improve prediction confidence
    
    Runs inference on multiple augmented versions and averages results
    Reduces uncertainty and improves accuracy
    
    Args:
        model: PyTorch model
        img_tensor: Input tensor (1, 3, H, W)
        device: Device to run on
    
    Returns:
        averaged_mask: Final prediction mask
        confidence_map: Confidence scores
    """
    print("  🔄 Applying Test-Time Augmentation (TTA)...")
    
    h, w = img_tensor.shape[2:]
    predictions = []
    
    # Original
    with torch.no_grad():
        logits = model(img_tensor)
        probs = F.softmax(logits, dim=1)
        predictions.append(probs)
    
    # Horizontal flip
    img_flipped = torch.flip(img_tensor, dims=[3])
    with torch.no_grad():
        logits = model(img_flipped)
        probs = F.softmax(logits, dim=1)
        probs = torch.flip(probs, dims=[3])  # Flip back
        predictions.append(probs)
    
    # Vertical flip
    img_flipped = torch.flip(img_tensor, dims=[2])
    with torch.no_grad():
        logits = model(img_flipped)
        probs = F.softmax(logits, dim=1)
        probs = torch.flip(probs, dims=[2])  # Flip back
        predictions.append(probs)
    
    # Both flips
    img_flipped = torch.flip(img_tensor, dims=[2, 3])
    with torch.no_grad():
        logits = model(img_flipped)
        probs = F.softmax(logits, dim=1)
        probs = torch.flip(probs, dims=[2, 3])  # Flip back
        predictions.append(probs)
    
    # Average all predictions
    avg_probs = torch.stack(predictions).mean(dim=0)
    
    # Get final prediction
    pred_mask = avg_probs.argmax(1)[0].cpu().numpy().astype(np.uint8)
    confidence_map = avg_probs.max(1)[0][0].cpu().numpy()
    
    print(f"  ✓ TTA complete (averaged 4 predictions)")
    return pred_mask, confidence_map


# ============ METHOD 2: Monte Carlo Dropout ============

def monte_carlo_dropout(model, img_tensor, n_iterations=10, dropout_rate=0.2, device='cuda'):
    """
    Estimate prediction uncertainty using Monte Carlo Dropout
    
    Enables dropout during inference and runs multiple forward passes
    Measures prediction variance as uncertainty
    
    Args:
        model: PyTorch model
        img_tensor: Input tensor
        n_iterations: Number of MC samples
        dropout_rate: Dropout probability
        device: Device
    
    Returns:
        pred_mask: Prediction
        uncertainty_map: Uncertainty scores (higher = less certain)
    """
    print(f"  🎲 Applying Monte Carlo Dropout ({n_iterations} iterations)...")
    
    # Enable dropout during inference
    def enable_dropout(m):
        if type(m) == torch.nn.Dropout:
            m.train()
    
    model.apply(enable_dropout)
    
    predictions = []
    with torch.no_grad():
        for i in range(n_iterations):
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)
            predictions.append(probs.cpu().numpy())
    
    # Stack predictions
    predictions = np.array(predictions)  # (n_iter, 1, C, H, W)
    
    # Mean prediction
    mean_probs = predictions.mean(axis=0)[0]  # (C, H, W)
    pred_mask = mean_probs.argmax(axis=0).astype(np.uint8)  # (H, W)
    
    # Uncertainty: standard deviation across iterations
    std_probs = predictions.std(axis=0)[0]  # (C, H, W)
    uncertainty_map = std_probs.max(axis=0)  # (H, W)
    
    # Set model back to eval mode
    model.eval()
    
    print(f"  ✓ MC Dropout complete (uncertainty estimated)")
    return pred_mask, uncertainty_map


# ============ METHOD 3: Conditional Random Field (CRF) ============

def apply_dense_crf(img_rgb, mask_probs, num_classes=16):
    """
    Apply Dense CRF for boundary refinement
    
    Requires: pip install pydensecrf
    
    Args:
        img_rgb: Original image (H, W, 3)
        mask_probs: Probability map (C, H, W)
        num_classes: Number of classes
    
    Returns:
        refined_mask: CRF-refined segmentation
    """
    try:
        import pydensecrf.densecrf as dcrf
        from pydensecrf.utils import unary_from_softmax, create_pairwise_bilateral
        
        print("  🌐 Applying Dense CRF...")
        
        h, w = img_rgb.shape[:2]
        
        # Create DenseCRF object
        d = dcrf.DenseCRF2D(w, h, num_classes)
        
        # Set unary potentials
        unary = unary_from_softmax(mask_probs)
        d.setUnaryEnergy(unary)
        
        # Pairwise potentials
        # Appearance kernel
        d.addPairwiseGaussian(sxy=3, compat=3)
        
        # Bilateral kernel (considers both spatial and color similarity)
        d.addPairwiseBilateral(sxy=50, srgb=5, rgbim=img_rgb, compat=10)
        
        # Inference
        Q = d.inference(5)  # 5 iterations
        refined_probs = np.array(Q).reshape((num_classes, h, w))
        
        refined_mask = refined_probs.argmax(axis=0).astype(np.uint8)
        
        print("  ✓ CRF refinement complete")
        return refined_mask
        
    except ImportError:
        print("  ⚠️  pydensecrf not installed. Skipping CRF.")
        print("  Install with: pip install git+https://github.com/lucasb-eyer/pydensecrf.git")
        return None


# ============ METHOD 4: Morphological Post-Processing ============

def advanced_morphological_cleaning(mask, min_area=100):
    """
    Advanced morphological operations for cleaning segmentation
    
    - Removes small noise
    - Fills holes
    - Smooths boundaries
    - Removes tiny disconnected components
    
    Args:
        mask: Segmentation mask (H, W)
        min_area: Minimum area (pixels) to keep
    
    Returns:
        cleaned_mask: Cleaned segmentation
    """
    print("  🧹 Applying morphological cleaning...")
    
    cleaned_mask = mask.copy()
    
    # Process each class separately
    unique_classes = np.unique(mask)
    
    for class_id in unique_classes:
        if class_id == 0:  # Skip background
            continue
        
        binary = (mask == class_id).astype(np.uint8)
        
        # Opening: remove noise
        kernel = np.ones((3, 3), np.uint8)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
        
        # Closing: fill holes
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
        
        # Remove small components
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        
        for i in range(1, num_labels):
            area = stats[i, cv2.CC_STAT_AREA]
            if area < min_area:
                binary[labels == i] = 0
        
        # Update mask
        cleaned_mask[binary == 1] = class_id
    
    print("  ✓ Morphological cleaning complete")
    return cleaned_mask


# ============ METHOD 5: Ensemble Prediction ============

def ensemble_predictions(models, img_tensor, device='cuda'):
    """
    Combine predictions from multiple models
    
    Args:
        models: List of PyTorch models
        img_tensor: Input tensor
        device: Device
    
    Returns:
        ensemble_mask: Final prediction
        confidence_map: Confidence scores
    """
    print(f"  🤝 Ensemble prediction ({len(models)} models)...")
    
    all_probs = []
    
    for i, model in enumerate(models):
        model.eval()
        with torch.no_grad():
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)
            all_probs.append(probs)
    
    # Average all predictions
    avg_probs = torch.stack(all_probs).mean(dim=0)
    
    pred_mask = avg_probs.argmax(1)[0].cpu().numpy().astype(np.uint8)
    confidence_map = avg_probs.max(1)[0][0].cpu().numpy()
    
    print("  ✓ Ensemble complete")
    return pred_mask, confidence_map


# ============ METHOD 6: Uncertainty-Based Filtering ============

def filter_low_confidence_regions(mask, confidence_map, threshold=0.7):
    """
    Mark low-confidence regions as uncertain
    
    Helps identify regions where the model is not confident
    
    Args:
        mask: Prediction mask
        confidence_map: Confidence scores
        threshold: Confidence threshold
    
    Returns:
        filtered_mask: Mask with low-confidence regions marked
        uncertain_regions: Binary map of uncertain areas
    """
    print(f"  ⚖️  Filtering low-confidence regions (threshold={threshold})...")
    
    uncertain_regions = (confidence_map < threshold)
    filtered_mask = mask.copy()
    
    # Optionally set uncertain regions to background (class 0)
    # filtered_mask[uncertain_regions] = 0
    
    uncertain_percentage = (uncertain_regions.sum() / uncertain_regions.size) * 100
    print(f"  ⚠️  {uncertain_percentage:.1f}% of pixels have low confidence")
    
    return filtered_mask, uncertain_regions


# ============ USAGE EXAMPLE ============

def apply_ml_postprocessing_pipeline(model, img_tensor, img_rgb, device='cuda', 
                                      use_tta=True, use_mc_dropout=False, 
                                      use_crf=False, use_morphology=True):
    """
    Complete ML post-processing pipeline
    
    Combines multiple methods for best results
    
    Args:
        model: PyTorch model
        img_tensor: Input tensor
        img_rgb: Original RGB image
        device: Device
        use_tta: Apply test-time augmentation
        use_mc_dropout: Apply Monte Carlo dropout
        use_crf: Apply CRF refinement
        use_morphology: Apply morphological cleaning
    
    Returns:
        final_mask: Processed segmentation
        confidence_map: Confidence scores
    """
    print("\n🔬 ML POST-PROCESSING PIPELINE")
    print("=" * 60)
    
    # 1. Base prediction or TTA
    if use_tta:
        mask, confidence_map = test_time_augmentation(model, img_tensor, device)
    else:
        with torch.no_grad():
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)
            mask = logits.argmax(1)[0].cpu().numpy().astype(np.uint8)
            confidence_map = probs.max(1)[0][0].cpu().numpy()
    
    # 2. Uncertainty estimation (optional)
    if use_mc_dropout:
        mask, uncertainty = monte_carlo_dropout(model, img_tensor, n_iterations=10, device=device)
        # Combine with confidence
        confidence_map = 1 - uncertainty  # Convert uncertainty to confidence
    
    # 3. Morphological cleaning
    if use_morphology:
        mask = advanced_morphological_cleaning(mask, min_area=50)
    
    # 4. CRF refinement (optional, slow)
    if use_crf:
        # Need probability map for CRF
        with torch.no_grad():
            logits = model(img_tensor)
            probs = F.softmax(logits, dim=1)[0].cpu().numpy()
        
        refined_mask = apply_dense_crf(img_rgb, probs, num_classes=16)
        if refined_mask is not None:
            mask = refined_mask
    
    print("=" * 60)
    print("✅ Post-processing complete\n")
    
    return mask, confidence_map


if __name__ == "__main__":
    print("🧠 ML Post-Processing Module")
    print("\nAvailable Methods:")
    print("1. Test-Time Augmentation (TTA) - Improves accuracy ~2-5%")
    print("2. Monte Carlo Dropout - Estimates uncertainty")
    print("3. Dense CRF - Refines boundaries")
    print("4. Morphological Cleaning - Removes noise")
    print("5. Ensemble Prediction - Combines multiple models")
    print("6. Confidence Filtering - Identifies uncertain regions")
    print("\nImport this module in your inference script to use these methods.")
